package firealarm_freak.plugins.fctf.config;

import firealarm_freak.plugins.fctf.Main;

public class ConfigManager {
	public static Main plugin;
	
	public static void loadConfig() {
		
	}
}
